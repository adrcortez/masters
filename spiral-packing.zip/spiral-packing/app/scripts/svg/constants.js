'use strict';


angular.module('svg.constants', [])

    .constant('primaryColors', ['#C92131', '#FEEF35', '#0A5BA6'])
    .constant('secondaryColors', ['#EB7030', '#3AA744', '#5D2D82'])
    .constant('tertiaryColors', [ '#E64927', '#F7AA30', '#B6CF38', '#169C7E', '#3E3183', '#7D2981']);
