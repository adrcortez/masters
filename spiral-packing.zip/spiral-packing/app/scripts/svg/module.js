'use strict';


angular.module('svg', [
    'base64',

    'svg.constants',
    'svg.factories',
    'svg.services',
    'svg.directives'
]);
