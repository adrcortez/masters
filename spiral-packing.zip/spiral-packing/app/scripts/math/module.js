'use strict';


angular.module('math', [
    'math.factories',
    'math.services'
]);
